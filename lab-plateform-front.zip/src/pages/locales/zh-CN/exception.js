export default {
  'app.exception.back': '返回首页',
  'app.exception.description.403': '抱歉，你无权访问该页面',
  'app.exception.description.404': '抱歉，你访问的页面不存在',
  'app.exception.description.500': '抱歉，服务器出错了',
};
