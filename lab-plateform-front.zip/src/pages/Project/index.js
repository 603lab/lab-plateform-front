import React, { PureComponent } from 'react';

export default class ProjectPage extends PureComponent {
  constructor(props) {
    super(props);

    this.state = {};
  }

  render() {
    return <div>ProjectPage</div>;
  }
}
