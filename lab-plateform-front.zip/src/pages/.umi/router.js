import React from 'react';
import { Router as DefaultRouter, Route, Switch } from 'react-router-dom';
import dynamic from 'umi/dynamic';
import renderRoutes from 'umi/_renderRoutes';
import RendererWrapper0 from '/Users/chenxiaobin/Youzan/code/lab-platform/lab-plateform-front/src/pages/.umi/LocaleWrapper.jsx'
import _dvaDynamic from 'dva/dynamic'

let Router = require('dva/router').routerRedux.ConnectedRouter;

let routes = [
  {
    "path": "/user",
    "component": _dvaDynamic({
  
  component: () => import('../../layouts/UserLayout'),
  LoadingComponent: require('/Users/chenxiaobin/Youzan/code/lab-platform/lab-plateform-front/src/components/PageLoading/index').default,
}),
    "routes": [
      {
        "path": "/user",
        "redirect": "/user/login",
        "exact": true
      },
      {
        "path": "/user/login",
        "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('/Users/chenxiaobin/Youzan/code/lab-platform/lab-plateform-front/src/pages/User/models/register.js').then(m => { return { namespace: 'register',...m.default}})
],
  component: () => import('../User/Login'),
  LoadingComponent: require('/Users/chenxiaobin/Youzan/code/lab-platform/lab-plateform-front/src/components/PageLoading/index').default,
}),
        "exact": true
      },
      {
        "component": () => React.createElement(require('/Users/chenxiaobin/Youzan/code/lab-platform/lab-plateform-front/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
      }
    ]
  },
  {
    "path": "/",
    "component": _dvaDynamic({
  
  component: () => import('../../layouts/BasicLayout'),
  LoadingComponent: require('/Users/chenxiaobin/Youzan/code/lab-platform/lab-plateform-front/src/components/PageLoading/index').default,
}),
    "routes": [
      {
        "path": "/",
        "redirect": "/home",
        "exact": true
      },
      {
        "path": "/home",
        "name": "home",
        "icon": "home",
        "component": _dvaDynamic({
  
  component: () => import('../Home/index'),
  LoadingComponent: require('/Users/chenxiaobin/Youzan/code/lab-platform/lab-plateform-front/src/components/PageLoading/index').default,
}),
        "exact": true
      },
      {
        "path": "/doc",
        "name": "doc",
        "icon": "inbox",
        "component": _dvaDynamic({
  
  component: () => import('../Encyclopedia/index'),
  LoadingComponent: require('/Users/chenxiaobin/Youzan/code/lab-platform/lab-plateform-front/src/components/PageLoading/index').default,
}),
        "exact": true
      },
      {
        "path": "/project",
        "name": "project",
        "icon": "project",
        "component": _dvaDynamic({
  
  component: () => import('../Project/index'),
  LoadingComponent: require('/Users/chenxiaobin/Youzan/code/lab-platform/lab-plateform-front/src/components/PageLoading/index').default,
}),
        "exact": true
      },
      {
        "name": "account",
        "icon": "user",
        "path": "/account/center",
        "component": _dvaDynamic({
  
  component: () => import('../Account/Center/Center'),
  LoadingComponent: require('/Users/chenxiaobin/Youzan/code/lab-platform/lab-plateform-front/src/components/PageLoading/index').default,
}),
        "routes": [
          {
            "path": "/account/center",
            "redirect": "/account/center/articles",
            "exact": true
          },
          {
            "path": "/account/center/articles",
            "component": _dvaDynamic({
  
  component: () => import('../Account/Center/Articles'),
  LoadingComponent: require('/Users/chenxiaobin/Youzan/code/lab-platform/lab-plateform-front/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/account/center/doc",
            "component": _dvaDynamic({
  
  component: () => import('../Account/Center/Encyclopedia'),
  LoadingComponent: require('/Users/chenxiaobin/Youzan/code/lab-platform/lab-plateform-front/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/account/center/projects",
            "component": _dvaDynamic({
  
  component: () => import('../Account/Center/Projects'),
  LoadingComponent: require('/Users/chenxiaobin/Youzan/code/lab-platform/lab-plateform-front/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "component": () => React.createElement(require('/Users/chenxiaobin/Youzan/code/lab-platform/lab-plateform-front/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
          }
        ]
      },
      {
        "hideInMenu": true,
        "path": "/account/settings",
        "name": "account.settings",
        "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('/Users/chenxiaobin/Youzan/code/lab-platform/lab-plateform-front/src/pages/Account/Settings/models/geographic.js').then(m => { return { namespace: 'geographic',...m.default}})
],
  component: () => import('../Account/Settings/Info'),
  LoadingComponent: require('/Users/chenxiaobin/Youzan/code/lab-platform/lab-plateform-front/src/components/PageLoading/index').default,
}),
        "routes": [
          {
            "path": "/account/settings",
            "redirect": "/account/settings/base",
            "exact": true
          },
          {
            "path": "/account/settings/base",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('/Users/chenxiaobin/Youzan/code/lab-platform/lab-plateform-front/src/pages/Account/Settings/models/geographic.js').then(m => { return { namespace: 'geographic',...m.default}})
],
  component: () => import('../Account/Settings/BaseView'),
  LoadingComponent: require('/Users/chenxiaobin/Youzan/code/lab-platform/lab-plateform-front/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/account/settings/security",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('/Users/chenxiaobin/Youzan/code/lab-platform/lab-plateform-front/src/pages/Account/Settings/models/geographic.js').then(m => { return { namespace: 'geographic',...m.default}})
],
  component: () => import('../Account/Settings/SecurityView'),
  LoadingComponent: require('/Users/chenxiaobin/Youzan/code/lab-platform/lab-plateform-front/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/account/settings/binding",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('/Users/chenxiaobin/Youzan/code/lab-platform/lab-plateform-front/src/pages/Account/Settings/models/geographic.js').then(m => { return { namespace: 'geographic',...m.default}})
],
  component: () => import('../Account/Settings/BindingView'),
  LoadingComponent: require('/Users/chenxiaobin/Youzan/code/lab-platform/lab-plateform-front/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/account/settings/notification",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('/Users/chenxiaobin/Youzan/code/lab-platform/lab-plateform-front/src/pages/Account/Settings/models/geographic.js').then(m => { return { namespace: 'geographic',...m.default}})
],
  component: () => import('../Account/Settings/NotificationView'),
  LoadingComponent: require('/Users/chenxiaobin/Youzan/code/lab-platform/lab-plateform-front/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "component": () => React.createElement(require('/Users/chenxiaobin/Youzan/code/lab-platform/lab-plateform-front/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
          }
        ]
      },
      {
        "component": _dvaDynamic({
  
  component: () => import('../404'),
  LoadingComponent: require('/Users/chenxiaobin/Youzan/code/lab-platform/lab-plateform-front/src/components/PageLoading/index').default,
}),
        "exact": true
      },
      {
        "component": () => React.createElement(require('/Users/chenxiaobin/Youzan/code/lab-platform/lab-plateform-front/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
      }
    ]
  },
  {
    "component": () => React.createElement(require('/Users/chenxiaobin/Youzan/code/lab-platform/lab-plateform-front/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
  }
];
window.g_routes = routes;
window.g_plugins.applyForEach('patchRoutes', { initialValue: routes });

// route change handler
function routeChangeHandler(location, action) {
  window.g_plugins.applyForEach('onRouteChange', {
    initialValue: {
      routes,
      location,
      action,
    },
  });
}
window.g_history.listen(routeChangeHandler);
routeChangeHandler(window.g_history.location);

export default function RouterWrapper() {
  return (
<RendererWrapper0>
          <Router history={window.g_history}>
      { renderRoutes(routes, {}) }
    </Router>
        </RendererWrapper0>
  );
}
