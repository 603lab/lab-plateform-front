export const noticeList = [
  {
    id: '1',
    mainTitle: '号外！号外！最新公告',
    subHead: '学长学姐干货推荐！',
    content:
      '刚刚入门我应该选择的方向是什么这个疑惑了我很长时间。。。XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX',
    createUserName: 'admin',
    lastEditTime: '2019-02-11T15:55:01',
  },
  {
    id: '2',
    mainTitle: '新学期注意事项',
    subHead: '新学期注意事项',
    content:
      '同学们新学期开始了，不要忘记打卡，这是我们很重要的工作之一哦。每天督促自己一点点，每天进步一点点',
    createUserName: 'admin',
    lastEditTime: '2019-03-05T11:55:01',
  },
  {
    id: '3',
    mainTitle: '这里是第三条信息',
    subHead: '注意查收',
    content: '严禁究极划水事件，请务必正常打卡下班',
    createUserName: 'admin',
    lastEditTime: '2019-03-2T13:25:21',
  },
  {
    id: '4',
    mainTitle: '这里是第四条信息',
    subHead: '浙传新闻社找人',
    content: '招收新闻主播以及记者，觉得自己又能力的孩子可以来争取一下',
    createUserName: '浙传新闻社',
    lastEditTime: '2019-03-5T13:25:21',
  },
  {
    id: '5',
    mainTitle: '百团大战，水社团当道',
    subHead: '注意查收',
    content: '严禁究极划水事件，请务必正常打卡下班',
    createUserName: 'admin',
    lastEditTime: '2019-03-21T13:25:21',
  },
  {
    id: '6',
    mainTitle: '奔走相告',
    subHead: '期末考不及格的不用来了',
    content: '我们不需要愚笨的孩子，再说一遍 我们不需要你',
    createUserName: '愚笨的孩子',
    lastEditTime: '2018-01-21T13:25:21',
  },
];
